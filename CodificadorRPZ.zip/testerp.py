import PyPDF2
import re
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

# Função para ler PDF
def ler_pdf(file_path):
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
    return text

# Função para ler arquivos TXT e RPC
def ler_txt_rpc(file_path):
    with open(file_path, "r") as file:
        return file.readlines()

# Função para extrair os domínios
def extrair_dominios(texto):
    padrao_dominio = r'\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b'
    dominios = re.findall(padrao_dominio, texto)
    return dominios

# Função para gerar o arquivo RPZ no formato padrão DNS Zone
def gerar_rpz_dns_format(domains):
    # Obtendo a data atual no formato YYYYMMDD
    data_atual = datetime.now().strftime("%Y%m%d")
    
    # Definindo o serial com o sufixo "01" conforme solicitado
    serial = f"{data_atual}01"
    
    # Criando as entradas do arquivo RPZ
    rpz_entries = []
    rpz_entries.append("$TTL 60\n")
    rpz_entries.append("@   IN  SOA localhost. root.localhost. (\n")
    rpz_entries.append(f"        {serial} ; serial\n")  # Usando o serial dinâmico
    rpz_entries.append("        1h         ; refresh\n")
    rpz_entries.append("        30m        ; retry\n")
    rpz_entries.append("        1w         ; expiry\n")
    rpz_entries.append("        30m)       ; minimum\n\n")
    rpz_entries.append("        IN  NS    localhost.\n")
    rpz_entries.append("localhost. IN A 127.0.0.1\n\n")

    for domain in domains:
        domain = domain.strip()
        if domain:
            rpz_entries.append(f"{domain} IN A 127.0.0.1\n")
            rpz_entries.append(f"{domain} IN AAAA ::1\n")

    return rpz_entries

# Função para salvar o arquivo RPZ
def salvar_rpz(file_path, rpz_entries):
    with open(file_path, "w") as file:
        file.writelines(rpz_entries)

# Função principal para processar arquivos PDF, TXT ou RPC
def processar_arquivo(file_path, output_path):
    if file_path.endswith(".pdf"):
        texto = ler_pdf(file_path)
        domains = texto.splitlines()
    elif file_path.endswith(".txt") or file_path.endswith(".rpc") or file_path.endswith(".rsc"):
        domains = ler_txt_rpc(file_path)
    else:
        raise ValueError("Formato de arquivo não suportado. Use PDF, TXT, RPC ou RSC.")

    dominios_extraidos = extrair_dominios("\n".join(domains))
    rpz_entries = gerar_rpz_dns_format(dominios_extraidos)
    salvar_rpz(output_path, rpz_entries)
    return output_path

# Função para abrir o seletor de arquivos
def escolher_arquivo():
    arquivo = filedialog.askopenfilename(
        title="Selecione o arquivo de entrada",
        filetypes=(("Todos os arquivos", "*.*"), ("PDF files", "*.pdf"), ("Text files", "*.txt"), ("RPC files", "*.rpc"), ("RSC files", "*.rsc"))
    )
    entrada_var.set(arquivo)

# Função para gerar o RPZ
def gerar_rpz():
    arquivo_entrada = entrada_var.get()
    if not arquivo_entrada:
        messagebox.showwarning("Aviso", "Por favor, selecione um arquivo de entrada.")
        return

    caminho_saida = filedialog.asksaveasfilename(
        title="Salvar arquivo RPZ como",
        defaultextension=".txt",
        filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
    )
    if not caminho_saida:
        return

    try:
        arquivo_rpz = processar_arquivo(arquivo_entrada, caminho_saida)
        messagebox.showinfo("Sucesso", f"Arquivo RPZ gerado com sucesso: {arquivo_rpz}")
    except Exception as e:
        messagebox.showerror("Erro", f"Ocorreu um erro ao gerar o arquivo RPZ: {str(e)}")

# Criação da interface Tkinter
root = tk.Tk()
root.title("Gerador de Arquivo RPZ")

# Variável para armazenar o caminho do arquivo de entrada
entrada_var = tk.StringVar()

# Botão para escolher o arquivo
btn_escolher = tk.Button(root, text="Escolher Arquivo", command=escolher_arquivo)
btn_escolher.grid(row=0, column=0, padx=10, pady=10)

# Campo de texto para mostrar o caminho do arquivo escolhido
entrada_arquivo = tk.Entry(root, textvariable=entrada_var, width=50)
entrada_arquivo.grid(row=0, column=1, padx=10, pady=10)

# Botão para gerar o arquivo RPZ
btn_gerar = tk.Button(root, text="Gerar RPZ", command=gerar_rpz)
btn_gerar.grid(row=1, column=0, columnspan=2, pady=10)

# Executa a interface Tkinter
root.mainloop()
